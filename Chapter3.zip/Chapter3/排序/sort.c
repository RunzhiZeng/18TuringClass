#include<stdio.h>

void BubbleSort(int a[], int len);
void InsertionSort(int a[], int len);
void SelectionSort(int a[], int len);


int main(void){
    int a[16] = {123,1221,12546,7658,47589,3457435,4578565,57575,3534,634,7547432,235,67576,22,347645,131};
    int b[16] = {123,1221,12546,7658,47589,3457435,4578565,57575,3534,634,7547432,235,67576,22,347645,131};
    int c[16] = {123,1221,12546,7658,47589,3457435,4578565,57575,3534,634,7547432,235,67576,22,347645,131};

    BubbleSort(a, 16);
    InsertionSort(b, 16);
    SelectionSort(c, 16);

    for(int i = 0; i < 16; i++){
        printf("%d  ", a[i]);
    }
    printf("\n");
    for(int i = 0; i < 16; i++){
        printf("%d  ", b[i]);
    }
    printf("\n");
    for(int i = 0; i < 16; i++){
        printf("%d  ", c[i]);
    }    

    return 0;
}

void BubbleSort(int a[], int len){
    int i,j;
    for(i = 0 ; i < len - 1 ; i++){
		for(j = 0 ; j < len - i - 1 ; j++)          
			if(a[j] > a[j+1]){
				int t = a[j];
				a[j] = a[j+1];
				a[j+1] = t;
			}
	}
    return;
}

void SelectionSort(int a[],int len){
    int i,j;  
    for(i = 0 ; i < len-1 ; i++){
        int min_index = i;      
        for(j = i + 1 ; j < len; j++)            
            if(a[ min_index ] > a[j])
                min_index = j;
        if(min_index != i){ 
            int temp = a[i];  
            a[i] = a[min_index];  
            a[min_index] = temp;  
        }  
    }  
}

void InsertionSort(int a[], int len){
	int i, j, key;
	for(i = 1; i < len; i++){
		key = a[i];
		for(j = i - 1; j >= 0; j--){
			if(a[j] > key){
				a[j + 1] = a[j];	
			}
            else{
				break;
			}
		}
		a[j + 1] = key;
	}
}
