#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct {
    int data1;
    int data2;
} Node;

int main(void){

    /* 分配结构体动态数组 */
    int len = 10;
    Node* arrayOfNode = (Node*)malloc( sizeof(Node) * len);

    for(int i = 0; i < len; i++){
        arrayOfNode[i].data1 = i;
        (arrayOfNode+i)->data2 = 2*i;
    }

    for(int i = 0; i < len; i++){
        printf("%d\n", (arrayOfNode+i)->data1);
        printf("%d\n\n", arrayOfNode[i].data2);
    }

    /* 动态数组需要释放内存  */
    free(arrayOfNode);
    return 1;
}
