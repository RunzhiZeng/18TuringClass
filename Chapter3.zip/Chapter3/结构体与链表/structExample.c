#include<stdio.h>

/* 结构体第一种定义 */
struct Student1{
    int id;
    int score;
};

/* 结构体第二种定义 */
typedef struct asdasd{
    int id;
    int score;
} Student2;

int main(void){

    /* 注意两种声明的区别 */
    struct Student1 s1;
    Student2 s2;

    
    s1.id = 2018022628;
    s1.score = 100;
    s2.id = 2018022629;
    s2.score = 59;

    printf("ID:%d, Score:%d\n", s1.id, s1.score);
    printf("ID:%d, Score:%d\n", s2.id, s2.score);

    /* 结构体的地址 */
    printf("%p\n", &s1);
    printf("%p\n", &(s1.id));
    printf("%p\n", &s2);

    printf("\n\n");
    
    /* 结构体指针 */
    struct Student1* ss1 = &s1;
    Student2* ss2 = &s2;;
    /* ss2 = &s1; 报错！虽然Student1和Student2的内部定义是一样的，但它们仍然是不同的结构 */

    printf("%p\n", ss1);
    printf("%p\n", ss2);

    /* 用指针的方式访问结构体的内容 */
    printf("ID:%d, Score:%d\n", ss1->id, ss1->score);
    printf("ID:%d, Score:%d\n", ss2->id, ss2->score);

    /* 用指针解引用的方式访问结构体的内容 */
    
    printf("ID:%d, Score:%d\n", (*ss1).id, (*ss1).score);
    printf("ID:%d, Score:%d\n", (*ss2).id, (*ss2).score);

    return 1;
}
