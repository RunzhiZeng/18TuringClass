#include<stdio.h>

typedef struct _node{
    int data;
    struct _node* nextnode;  /* 觉得奇怪？先记着*/
    /* Wrong! node* nextnode2; */
} node;

int main(void){

    node n1;
    node n2;

    n1.data = 123123;
    n1.nextnode = NULL;
    n2.data = 456456;
    n2.nextnode = NULL;

    printf("%d\n", n1.data);
    printf("%d\n", n2.data);

    printf("\n");
    
    /* n1中的nextnode指针指向n2, n2中的nextnode指向n1  */
    n1.nextnode = &n2;
    n2.nextnode = &n1;

    printf("%d\n", (n1.nextnode)->data);
    printf("%d\n", (n2.nextnode)->data);    
    
    return 0;
}
