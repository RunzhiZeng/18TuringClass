/**************

链表定义示例
链表遍历

*************/

#include<stdio.h>
#include<stdlib.h>

typedef struct _LinkedList{
    int data;
    struct _LinkedList* nextnode;
} LinkedList;

int main(void){

    int len = 10;
    LinkedList* head = NULL; /* 注意该定义与LinkedList head的区别！ */
    /*  printf("%d\n",head->data);   */
    
    LinkedList* temp = NULL;
    LinkedList* newNode = NULL;
    
    /* head = (LinkedList*)malloc( sizeof(LinkedList) );    分配一个结点的空间，然后让head指向它 */
    
    /* temp = head;   此时temp 和 head 指向同一个地方！*/
    

    /* 建立一个有10个结点的链表 */
    for(int i = 0; i < 10; i++){   /* 已经分配了一个head结点，接下来只需要分配10个结点即可 */
        newNode = (LinkedList*)malloc( sizeof(LinkedList) );   /* 分配一个结点的空间，然后让newNode指向它 */
        newNode->data = i;
        newNode->nextnode = NULL;
        
        if( i == 0 ){
            /* 保存好头结点 */
            head = newNode;
            temp = head;
        }
        
        temp->nextnode = newNode;   /* 使temp的下一个结点为newNode，即往链表尾部插入一个结点 */
        temp = newNode;             /* temp始终指向链表尾端的结点 */
    }
    /*  此时构造了一个有10个结点的链表！该链表的头结点由head指向  */

    /* 遍历链表内容 */
    temp = head;
    for(int i = 0; i < 10; i++){ /*10个结点*/
        printf("%d->",temp->data);
        temp = temp->nextnode;          //往后移
    }
    printf("\n\n");
    
    /* 另外一种遍历方法！建议以后链表就这样遍历 */
    temp = head;
    while( temp != NULL ){
        printf("%d->", temp->data);
        temp = temp->nextnode;
    }
    printf("\n\n");
    
    /* 链表结点在内存中的位置不是连续的！ */
    temp = head;
    while( temp != NULL ){
        printf("%p->", temp);
        temp = temp->nextnode;
    }


    /* 释放链表所占用内存 */
    LinkedList* temp2;
    temp = head;
    while( temp != NULL ){
        temp2 = temp->nextnode;
        free(temp);
        temp = temp2;
    }
    

    return 0;

}
