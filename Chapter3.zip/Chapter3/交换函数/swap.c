#include<stdio.h>

/* 错误的交换函数 */
void swapWrong(int a, int b){
    int t = a;
    a = b;
    b = t;
    return;
}

/* 正确的交换函数 */
void swap(int *a, int *b){
    int t = *a;
    *a = *b;
    *b = t;
    return;
}

/* 可以装逼但是会错误的交换函数 */
void xorSwap(int *a, int *b){
    *a = *a ^ *b;
    *b = *a ^ *b;
    *a = *a ^ *b;
    return;
}

int main(){
    int a = 5, b = 10;
    swapWrong(a, b);
    printf("a = %d, b = %d\n", a, b);

    swap(&a, &b);
    printf("a = %d, b = %d\n", a, b);

    xorSwap(&a, &b);
    printf("a = %d, b = %d\n", a, b);

    swap(&a, &a);
    printf("a = %d, b = %d, 不变\n", a, b);
    xorSwap(&a, &a);
    printf("a = %d, b = %d\n", a, b);
    printf("a = %d ????\n", a);

    return 1;
}
