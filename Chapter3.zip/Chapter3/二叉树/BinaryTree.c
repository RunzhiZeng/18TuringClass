#include<stdio.h>
#include<stdlib.h>

typedef struct _TreeNode{
    int data;
    struct _TreeNode* left;
    struct _TreeNode* right;
} TreeNode;

TreeNode* buildNode(int Data);
void inorder(TreeNode* root);

int main(){

    TreeNode* root = NULL;
    TreeNode* Left = NULL;
    TreeNode* Right = NULL;

    root = buildNode(3);
    Left = buildNode(2);
    Right = buildNode(5);

    root->left = Left;
    root->right = Right;

    TreeNode* LeftLeft = NULL;
    LeftLeft = buildNode(1);
    Left->left = LeftLeft;

    TreeNode* RightRight = NULL;
    RightRight = buildNode(6);
    Right->right = RightRight;

    TreeNode* RightLeft = NULL;
    RightLeft = buildNode(4);
    Right->left = RightLeft;

    inorder(root);
    
    return 1;
}
    

TreeNode* buildNode(int Data){
    /* 分配出一个新结点，并用node指针指向它      */
    TreeNode *node = NULL;
    node = (TreeNode*)malloc( sizeof(TreeNode) );

    /*  初始化结点内容   */
    node->data = Data;
    node->left = NULL;
    node->right = NULL;

    /* 将该节点返回  */
    return node;
}

/* 中序遍历 */
void inorder(TreeNode* root){
    if( root == NULL )
        return;
    inorder(root->left);           /*  先遍历左子树 */
    printf("%d\n", root->data);    /*  访问根结点  */
    inorder(root->right);          /*  再遍历右子树  */
}
